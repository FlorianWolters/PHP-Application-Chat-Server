
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","DateTime"],["c","Exception"],["c","FlorianWolters\\Application\\Chat\\Command\\RunServerCommand"],["c","FlorianWolters\\Application\\Chat\\Model\\Message"],["c","FlorianWolters\\Application\\Chat\\Server"],["c","FlorianWolters\\Application\\Chat\\ServerApplication"]];
